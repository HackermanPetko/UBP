import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient, HttpParams} from '@angular/common/http'
import {HttpHeaders} from '@angular/common/http';
import { daemons } from '../REALDAEMON/daemons.model';
import {Observable} from 'rxjs/observable'
import { task } from './task.model';
import { LocalStService } from '../shared/localstorage.service';




@Injectable()
export class taskService {
  apiAdress: string;
  data: Array<task> = [];
  constructor(private _http: HttpClient, private localSt: LocalStService){
  this.apiAdress = 'http://localhost:63699/api/task/'
  }
  getTask(id: string): Observable<Array<task>> {
    let headers = new HttpHeaders().set('Authorization', 'Bearer '+this.localSt.getLocalStorage())
    console.log(id)
    return this._http.get<Array<task>>(this.apiAdress+id, {headers})
  }
}
