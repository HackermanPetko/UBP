import { Component, OnInit, Input } from '@angular/core';
import {taskService} from '../Tasks/taskService.service';
import {task} from '../Tasks/task.model';


@Component({
  selector: 'task',
  templateUrl: './task.component.html',
  inputs:["taskSelected"]
})
export class TaskComponent  {


}