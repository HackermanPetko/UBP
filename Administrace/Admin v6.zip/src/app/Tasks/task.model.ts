export class task
    {
        Id: number;
        IdConfig: number;
        BackupType: number;
        Format:number;
        RepeatInterval:number;
        MaxBackups:number;
    }
