import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient, HttpParams} from '@angular/common/http'
import {HttpHeaders} from '@angular/common/http';
import {Sources} from '../daemons.model';
import {Observable} from 'rxjs/observable'
import { headersToString } from 'selenium-webdriver/http';
import { LocalStService } from '../shared/localstorage.service';




@Injectable()
export class sourceService {
  apiAdress: string;
  data: Array<Sources> = [];
  something: string;
  source: Sources;
  constructor(private _http: HttpClient, private localSt:LocalStService){
  this.apiAdress = 'http://localhost:63699/api/Source/'
  this.something = "3";
  }
  getSource(id:string): Observable<Array<Sources>> {
    let headers = new HttpHeaders().set('Authorization', 'Bearer '+this.localSt.getLocalStorage())
    return this._http.get<Array<Sources>>(this.apiAdress+id, {headers})
  }
}