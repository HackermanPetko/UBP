import { Component, OnInit, Input } from '@angular/core';
import {sourceService} from './sourceService.service';
import {Sources} from '../daemons.model';


@Component({
  selector: 'sources',
  templateUrl: './source.component.html',
  inputs:["sourceSelected"]
})
export class SourceComponent  {


}