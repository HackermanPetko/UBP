import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient, HttpParams} from '@angular/common/http'
import {HttpHeaders} from '@angular/common/http';
import {Destinations} from '../daemons.model';
import {Observable} from 'rxjs/observable'
import { headersToString } from 'selenium-webdriver/http';
import { LocalStService } from '../shared/localstorage.service';




@Injectable()
export class destinationService {
  apiAdress: string;
  data: Array<Destinations> = [];
  something: string;
  source: Destinations;
  constructor(private _http: HttpClient,private localSt:LocalStService){
  this.apiAdress = 'http://localhost:63699/api/Destination/'
  this.something = "3";
  }
  getDestination(id:string): Observable<Array<Destinations>> {
    let headers = new HttpHeaders().set('Authorization', 'Bearer '+this.localSt.getLocalStorage())
    return this._http.get<Array<Destinations>>(this.apiAdress+id, {headers})
  }
}