import { Component, OnInit, Input } from '@angular/core';
import {destinationService} from './destinationService.service';
import {Destinations} from '../daemons.model';


@Component({
  selector: 'destination',
  templateUrl: './destination.component.html',
  inputs:["destinationSelected"]
})
export class DestinationComponent  {


}