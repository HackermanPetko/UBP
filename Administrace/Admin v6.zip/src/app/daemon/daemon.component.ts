import {Component, Input} from '@angular/core';
import {DaemonsService} from './daemonsService.service';
import {daemon} from './daemons.model';





@Component({
selector: "daemon",
templateUrl:'./daemon.component.html',
inputs:["daemonSelected"]

})
export class DaemonComponent{
//public daemonValue = {};


}


