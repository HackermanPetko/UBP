import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient, HttpParams} from '@angular/common/http'
import {HttpHeaders} from '@angular/common/http';
import { daemon, Tasks } from './daemons.model';
import {Observable} from 'rxjs/observable'




@Injectable()
export class DaemonsService {
  apiAdress: string;
  data: Array<daemon> = [];
  constructor(private _http: HttpClient){
  this.apiAdress = 'http://localhost:63699/api/Config'
  }
  getData(): Observable<Array<daemon>> {
    let headers = new HttpHeaders().set('Authorization', 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1bmlxdWVfbmFtZSI6IlRvbSIsIm5iZiI6MTUyMjgzNjY4NSwiZXhwIjoxNTIzNDQxNDg1LCJpYXQiOjE1MjI4MzY2ODUsImlzcyI6Imh0dHA6Ly9sb2NhbGhvc3Q6NjM2OTkiLCJhdWQiOiJodHRwOi8vbG9jYWxob3N0OjYzNjk5In0.8-URRcnN7Yqj9QE5RzHLpiSPf_W_DbSX5aUmwhyvxlc')
    return this._http.get<Array<daemon>>(this.apiAdress, {headers})
  }
}
