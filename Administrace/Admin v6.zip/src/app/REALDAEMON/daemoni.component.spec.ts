import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DaemoniComponent } from './daemoni.component';

describe('DaemoniComponent', () => {
  let component: DaemoniComponent;
  let fixture: ComponentFixture<DaemoniComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DaemoniComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DaemoniComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
