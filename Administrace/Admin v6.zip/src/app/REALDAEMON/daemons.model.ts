export class daemons
{
    Id: number;
    IsNew: boolean;
    DaemonName: string;
    DaemonMAC: string;
    LastConnected: DateTimeFormat;
    Comment: string;
}

