import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient, HttpParams} from '@angular/common/http'
import {HttpHeaders} from '@angular/common/http';
import { daemons } from '../REALDAEMON/daemons.model';
import {Observable} from 'rxjs/observable'
import { headersToString } from 'selenium-webdriver/http';
import { LocalStService } from '../shared/localstorage.service';




@Injectable()
export class realdaemonService {
  apiAdress: string;
  data: Array<daemons> = [];
  something: string;
  daemon: daemons;
  constructor(private _http: HttpClient, private localSt: LocalStService){
  this.apiAdress = 'http://localhost:63699/api/daemons/'
  this.something = "3";
  }
  getData(): Observable<Array<daemons>> {
    let headers = new HttpHeaders().set('Authorization', 'Bearer '+this.localSt.getLocalStorage())
    return this._http.get<Array<daemons>>(this.apiAdress, {headers})
  }




}

