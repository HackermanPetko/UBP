import { Component, OnInit, Input } from '@angular/core';
import {realdaemonService} from './/realdaemonService.service';
import {daemons} from './daemons.model';


@Component({
  selector: 'daemoni',
  templateUrl: './daemoni.component.html',
  inputs:["Selected"]
})
export class DaemoniComponent  {


}
