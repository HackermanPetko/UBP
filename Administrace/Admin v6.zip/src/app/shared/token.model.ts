export class Token{
    tokenString: string;


}