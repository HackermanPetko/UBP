import {Component, Input} from '@angular/core';
import {ConfigService} from './configService.service';
import {config} from './config.model';





@Component({
selector: "config",
templateUrl:'./config.component.html',
inputs:["configSelected"]

})
export class ConfigComponent{
//public daemonValue = {};


}


