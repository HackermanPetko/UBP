import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient, HttpParams} from '@angular/common/http'
import {HttpHeaders} from '@angular/common/http';
import { config, Tasks } from './config.model';
import {Observable} from 'rxjs/observable'




@Injectable()
export class ConfigService {
  apiAdress: string;
  data: Array<config> = [];
  constructor(private _http: HttpClient){
  this.apiAdress = 'http://localhost:63699/api/Config'
  }
  getData(): Observable<Array<config>> {
    let headers = new HttpHeaders().set('Authorization', 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1bmlxdWVfbmFtZSI6IlRvbSIsIm5iZiI6MTUyNDU3OTk5MiwiZXhwIjoxNTMzMjE5OTkyLCJpYXQiOjE1MjQ1Nzk5OTIsImlzcyI6Imh0dHA6Ly9sb2NhbGhvc3Q6NjM2OTkiLCJhdWQiOiJodHRwOi8vbG9jYWxob3N0OjYzNjk5In0.fL0lsgNQ4I-eMtCxCcA_9BPzFhoxOk8F0OWLxqrCr5Y')
    return this._http.get<Array<config>>(this.apiAdress, {headers})
  }

  getConfig(id:string): Observable<Array<config>> {
    let headers = new HttpHeaders().set('Authorization', 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1bmlxdWVfbmFtZSI6IlRvbSIsIm5iZiI6MTUyNDU3OTk5MiwiZXhwIjoxNTMzMjE5OTkyLCJpYXQiOjE1MjQ1Nzk5OTIsImlzcyI6Imh0dHA6Ly9sb2NhbGhvc3Q6NjM2OTkiLCJhdWQiOiJodHRwOi8vbG9jYWxob3N0OjYzNjk5In0.fL0lsgNQ4I-eMtCxCcA_9BPzFhoxOk8F0OWLxqrCr5Y')
    return this._http.get<Array<config>>(this.apiAdress+'/'+id, {headers})
  }
}
