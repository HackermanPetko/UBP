import {Injectable} from '@angular/core';
import {daemons} from '../REALDAEMON/daemons.model';
import {config} from '../config/config.model';
import { HttpClientModule, HttpClient, HttpParams} from '@angular/common/http'
import 'rxjs/add/operator/map'
import {Http} from '@angular/http';
import {HttpHeaders} from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import { map } from 'rxjs/operators';
import { NgModule} from '@angular/core'
import {task} from '../Tasks/task.model';
import {Sources} from '../daemons.model';
import {Destinations} from '../daemons.model';
import { LocalStService } from '../shared/localstorage.service';
import { User } from '../Users/user.model';





@Injectable()

export class PostService{

    constructor(private http: HttpClient, private localSt: LocalStService){}

    readonly ROOT_URL = 'http://localhost:63699/api/Config';
    posts: Observable<any>;
    newPost: Observable<any>;


    postConfig(configSelected:config)
{
  let headers = new HttpHeaders().set('Authorization', 'Bearer '+this.localSt.getLocalStorage())
  const req = this.http.post("http://localhost:63699/api/config",configSelected
 , {headers})
      .subscribe(
        res => {
          console.log(res);
        },
        err => {
          console.log("Error occured");
        }
      );
}

postDaemon(Selected:daemons)
{
  let headers = new HttpHeaders().set('Authorization', 'Bearer '+this.localSt.getLocalStorage())
  const req = this.http.put("http://localhost:63699/api/daemons",Selected
 , {headers})
      .subscribe(
        res => {
          console.log(res);
        },
        err => {
          console.log("Error occured");
        }
      );
}

postTask(taskSelected:task)
{
  let headers = new HttpHeaders().set('Authorization', 'Bearer '+this.localSt.getLocalStorage())
  const req = this.http.post("http://localhost:63699/api/task",taskSelected
 , {headers})
      .subscribe(
        res => {
          console.log(res);
        },
        err => {
          console.log("Error occured");
        }
      );
}

postSource(sourceSelected:Sources)
{
  let headers = new HttpHeaders().set('Authorization', 'Bearer '+this.localSt.getLocalStorage())
  const req = this.http.post("http://localhost:63699/api/task",sourceSelected
 , {headers})
      .subscribe(
        res => {
          console.log(res);
        },
        err => {
          console.log("Error occured");
        }
      );
}

postDestination(destinationSelected:Destinations)
{
  let headers = new HttpHeaders().set('Authorization', 'Bearer '+this.localSt.getLocalStorage())
  const req = this.http.post("http://localhost:63699/api/task",destinationSelected
 , {headers})
      .subscribe(
        res => {
          console.log(res);
        },
        err => {
          console.log("Error occured");
        }
      );
}

postUser(newUser:User)
{
  let headers = new HttpHeaders().set('Authorization', 'Bearer '+this.localSt.getLocalStorage())
  const req = this.http.post("http://localhost:63699/api/Register",newUser
 , {headers})
      .subscribe(
        res => {
          console.log(res);
        },
        err => {
          console.log("Error occured");
        }
      );
}


}











