import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditDaemonComponent } from './edit-daemon.component';

describe('EditDaemonComponent', () => {
  let component: EditDaemonComponent;
  let fixture: ComponentFixture<EditDaemonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditDaemonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditDaemonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
