import { Component, OnInit } from '@angular/core';
import { headersToString } from 'selenium-webdriver/http';
import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient, HttpParams} from '@angular/common/http'
import {HttpHeaders} from '@angular/common/http';
import { daemons } from '..//REALDAEMON/daemons.model';
import {realdaemonService} from '../REALDAEMON/realdaemonService.service'
import {DaemoniComponent} from '../REALDAEMON/daemoni.component';
import {Observable} from 'rxjs/observable'
@Component({
  selector: 'app-edit-daemon',
  templateUrl: './edit-daemon.component.html',
  styleUrls: ['./edit-daemon.component.css']
})
export class EditDaemonComponent implements OnInit {
apiAdress: string;
something: string;
data: Array<daemons> = [];
  constructor(private _http: HttpClient){
    
    }

  ngOnInit() {
  }
  getDataa():Observable<Array<daemons>>
  {
    let headers = new HttpHeaders().set('Authorization', 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1bmlxdWVfbmFtZSI6IlRvbSIsIm5iZiI6MTUyMzM1MDc5OCwiZXhwIjoxNTIzOTU1NTk4LCJpYXQiOjE1MjMzNTA3OTgsImlzcyI6Imh0dHA6Ly9sb2NhbGhvc3Q6NjM2OTkiLCJhdWQiOiJodHRwOi8vbG9jYWxob3N0OjYzNjk5In0.QsQqpBfYrE7C32_yLaGktOKscxF2X6yxmU8-FhkWUBw')
   console.log(this._http.get<Array<daemons[]>>("http://localhost:63699/api/daemons/3", {headers}))
    return this._http.get<Array<daemons>>("http://localhost:63699/api/daemons/3", {headers})
  } 
}
