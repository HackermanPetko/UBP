import { Component, OnInit } from '@angular/core';
import{ LocalStService } from '../shared/localstorage.service';
import { AppRoutingModule } from '../app-routing.module';
import { RouterModule, Routes, RouterLink, Router, RouterLinkWithHref } from '@angular/router';
import { config } from '../config/config.model';
import {ConfigService} from '../config/configService.service'
import {ConfigComponent} from '../config/config.component';
import { PostService } from '../post/post.service';
import {
  MatAutocompleteModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatChipsModule,
  MatDatepickerModule,
  MatDialogModule,
  MatDividerModule,
  MatExpansionModule,
  MatGridListModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatNativeDateModule,
  MatPaginatorModule,
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatRadioModule,
  MatRippleModule,
  MatSelectModule,
  MatSliderModule,
  MatSlideToggleModule,
  MatSnackBarModule,
  MatSortModule,
  MatStepperModule,
  MatTableModule,
  MatTabsModule,
  MatToolbarModule,
  MatTooltipModule,
} from '@angular/material';
import {MatSidenavModule} from '@angular/material/sidenav';


@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  constructor(private router: Router, private localSt:LocalStService, private configSer:ConfigService, private post:PostService) { }
  public configs: Array<config>;
  public selectedConfig;
  ngOnInit() {
this.getConfig();

  }



logoutUser(){
this.localSt.delLocalStorage();
this.router.navigateByUrl('/');
alert("You have been logged out!")

}



onSelect(config){
  this.selectedConfig = config;
}

getConfig(){
this.configSer.getData().subscribe((data: any)=>this.configs=data);
}

postDaemon(){

  this.post.postConfig(this.selectedConfig);
}
daemonsNavigate()
{
  this.router.navigateByUrl('/adminDaemons');
}
configsNavigate()
{
  this.router.navigateByUrl('/admin');
}
}
