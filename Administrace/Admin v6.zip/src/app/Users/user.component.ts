import { Component, OnInit } from '@angular/core';
import{ LocalStService } from '../shared/localstorage.service';
import { AppRoutingModule } from '../app-routing.module';
import { RouterModule, Routes, RouterLink, Router, RouterLinkWithHref } from '@angular/router';
import { daemons } from '..//REALDAEMON/daemons.model';
import {realdaemonService} from '../REALDAEMON/realdaemonService.service'
import {DaemoniComponent} from '../REALDAEMON/daemoni.component';
import { PostService } from '../post/post.service';
import { LocalStorageService } from 'ngx-webstorage';
import { NgModule } from '@angular/core';
import { HttpClient } from 'selenium-webdriver/http';
import { task} from '../Tasks/Task.model'
import {taskService} from '../Tasks/taskService.service'
import {ConfigService} from '../config/configService.service';
import { config } from '../config/config.model';
import {Sources} from '../daemons.model';
import {Destinations} from '../daemons.model';
import { sourceService } from '../Source/sourceService.service';
import {destinationService} from '../Destination/destinationService.service';
import { TaskslistComponent } from '../taskslist/taskslist.component';
import {User} from './user.model';
import {userService} from './userService.service';

@Component({
  selector: 'users',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {


  constructor(private router: Router, private localSt:LocalStService, private post: PostService,private userSer:userService) { }
users: Array<User>;
selectedUser: User;
newUser:User = {};




  ngOnInit() {
    this.getUsers()
  
  }

getUsers()
{
  this.userSer.getData().subscribe((data: any)=>this.users=data);
}


onSelect(user){
this.selectedUser = user;

}

deleteUser(deletedUser:User){

this.userSer.deleteUser(deletedUser);
this.ngOnInit();
}

postUser(){

this.post.postUser(this.newUser);
this.router.navigateByUrl('/users');


}


}