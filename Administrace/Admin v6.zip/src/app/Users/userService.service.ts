import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient, HttpParams} from '@angular/common/http'
import {HttpHeaders} from '@angular/common/http';
import { daemons } from '../REALDAEMON/daemons.model';
import {Observable} from 'rxjs/observable'
import { headersToString } from 'selenium-webdriver/http';
import { LocalStService } from '../shared/localstorage.service';
import { User } from './user.model';




@Injectable()
export class userService {
  apiAdress: string;
  data: Array<User> = [];
  something: string;
  user: User;
  constructor(private _http: HttpClient, private localSt: LocalStService){
  this.apiAdress = 'http://localhost:63699/api/user/'
  this.something = "3";
  }
  getData(): Observable<Array<User>> {
    let headers = new HttpHeaders().set('Authorization', 'Bearer '+this.localSt.getLocalStorage())
    return this._http.get<Array<User>>(this.apiAdress, {headers})
  }
  deleteUser(selectedUser:User)
  {
    let headers = new HttpHeaders().set('Authorization', 'Bearer '+this.localSt.getLocalStorage())
    const req = this._http.post("http://localhost:63699/api/User",selectedUser
   , {headers})
        .subscribe(
          res => {
            console.log(res);
          },
          err => {
            console.log("Error occured");
          }
        );

    }

}