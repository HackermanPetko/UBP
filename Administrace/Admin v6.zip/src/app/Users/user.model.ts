export class User{
    ID?:number;
    Username?: string;
    Password?: string;
    Email?:string;


}