import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpModule } from '@angular/http';
import { AppRoutingModule} from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginFormComponent } from './login-form/login-form.component';
import { FormsModule } from '@angular/forms';
import { AdminComponent } from './admin/admin.component';
import { RouterModule, Routes } from '@angular/router';
import {TokenService} from './shared/token.service';
import { HttpClientModule } from '@angular/common/http';
import {Ng2Webstorage, LocalStorage} from 'ngx-webstorage';
import { LocalStService } from './shared/localstorage.service';
import { ConfigService } from './config/configService.service';
import { ConfigComponent } from './config/config.component';
import {PostService} from './post/post.service';
import { Admin2Component } from './admin2/admin2.component';
import { DaemoniComponent } from './REALDAEMON/daemoni.component';
import { realdaemonService } from './REALDAEMON/realdaemonService.service';
import {sourceService} from './Source/sourceService.service';
import {SourceComponent} from './Source/source.component';
import {TaskComponent} from './Tasks/task.component';
import {destinationService} from './Destination/destinationService.service';
import {DestinationComponent} from './Destination/destination.component';


import {
  MatAutocompleteModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatChipsModule,
  MatDatepickerModule,
  MatDialogModule,
  MatDividerModule,
  MatExpansionModule,
  MatGridListModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatNativeDateModule,
  MatPaginatorModule,
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatRadioModule,
  MatRippleModule,
  MatSelectModule,
  MatSidenavModule,
  MatSliderModule,
  MatSlideToggleModule,
  MatSnackBarModule,
  MatSortModule,
  MatStepperModule,
  MatTableModule,
  MatTabsModule,
  MatToolbarModule,
  MatTooltipModule,
} from '@angular/material';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {taskService} from './Tasks/taskService.service';
import { DashboardComponent } from './dashboard/dashboard.component'
import {DaemonslistComponent} from './daemonslist/daemonslist.component'
import { TaskslistComponent } from './taskslist/taskslist.component';
import { UserComponent } from './Users/user.component';
import { userService } from './Users/userService.service';





@NgModule({
  declarations: [
    LoginFormComponent,
    AppComponent,
    AdminComponent,
    ConfigComponent,
    Admin2Component,
    DaemoniComponent,
    SourceComponent,
    TaskComponent,
    DestinationComponent,
    DashboardComponent,
    DaemonslistComponent,
    TaskslistComponent,
    UserComponent
    
    
  ],
  imports: [
    BrowserModule,
    HttpModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    Ng2Webstorage,
    MatSidenavModule,
    MatToolbarModule,
    MatListModule,
    BrowserAnimationsModule
   
  ],
  providers: [TokenService, HttpClientModule, LocalStService,ConfigService,PostService, realdaemonService, taskService,sourceService, destinationService,userService ],
  bootstrap: [AppComponent]
})
export class AppModule { }
