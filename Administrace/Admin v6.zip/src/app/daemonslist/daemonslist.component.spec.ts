import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DaemonslistComponent } from './daemonslist.component';

describe('DaemonslistComponent', () => {
  let component: DaemonslistComponent;
  let fixture: ComponentFixture<DaemonslistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DaemonslistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DaemonslistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
