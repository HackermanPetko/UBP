import { Component, OnInit } from '@angular/core';
import{ LocalStService } from '../shared/localstorage.service';
import { AppRoutingModule } from '../app-routing.module';
import { RouterModule, Routes, RouterLink, Router, RouterLinkWithHref } from '@angular/router';
import { daemons } from '..//REALDAEMON/daemons.model';
import {realdaemonService} from '../REALDAEMON/realdaemonService.service'
import {DaemoniComponent} from '../REALDAEMON/daemoni.component';
import { PostService } from '../post/post.service';
import { LocalStorageService } from 'ngx-webstorage';
import { NgModule } from '@angular/core';
import { HttpClient } from 'selenium-webdriver/http';
import { task} from '../Tasks/Task.model'
import {taskService} from '../Tasks/taskService.service'
import {ConfigService} from '../config/configService.service';
import { config } from '../config/config.model';
import {Sources} from '../daemons.model';
import {Destinations} from '../daemons.model';
import { sourceService } from '../Source/sourceService.service';
import {destinationService} from '../Destination/destinationService.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'tasks',
  templateUrl: './taskslist.component.html',
  styleUrls: ['./taskslist.component.css']
})
export class TaskslistComponent implements OnInit {


  constructor(private router: Router, private localSt:LocalStService, private realdaemoSvc: realdaemonService, private post: PostService,private taskSvc: taskService, private confSer:ConfigService, private srcSer: sourceService, private destSer:destinationService, private activeRoute: ActivatedRoute) { }
public realDaemon: Array<daemons>;
public selectedDaemon;
public selectedConfig;
public selectedTask;
public selectedSource;
public selectedId = null;
public selectedDestination;
public task: Array<task>;

public source: Array<Sources>;
public destination: Array<Destinations>;
public config: Array<config>
showEditDaemons:boolean = false;
showConfigs: boolean = false;
showEditConfigs: boolean = false;
showEditTasks:boolean = false;
showTasks: boolean = false;
showDaemons:boolean = true;
showSources:boolean = false;
showDestinations:boolean = false;
showEditDestinations:boolean = false;
showEditSources:boolean = false;
public showHide:boolean;


  ngOnInit() {
   
    this.activeRoute.params.subscribe( params => this.getTasks(params.id) );
  }
onSelect(task)
{
  this.selectedTask = task;
  this.showEditTasks = true;
}
onSelectConfig(config){
  this.selectedConfig = config;
  this.showEditConfigs = true;
}
onSelectTask(task){
  this.selectedTask = task;
  this.showEditTasks = true;
}
onSelectSource(source){
  this.selectedSource = source;
  this.showEditSources = true;
}
onSelectDestination(destination){
  this.selectedDestination = destination
  this.showEditDestinations = true;
}
getDaemons()
{
  this.realdaemoSvc.getData().subscribe((data: any)=>this.realDaemon=data);
}

getConfig(id:string){

  this.confSer.getConfig(id).subscribe((data: any)=>this.config=data)
  this.showConfigs=true;
  this.showDaemons = false;
  this.showEditDaemons = false;
}
getTasks(id:string)
{
  this.taskSvc.getTask(id).subscribe((data: any)=>this.task=data)
  this.showTasks=true;
  this.showConfigs = false;
  this.showEditConfigs = false;
}
getSources(id:string)
{
  this.srcSer.getSource(id).subscribe((data: any)=>this.source=data)
  this.showSources=true;
  this.getDestinations(id);
  this.showTasks=false;
  this.showEditTasks=false;
}
getDestinations(id:string)
{
  this.destSer.getDestination(id).subscribe((data: any)=>this.destination=data)
  this.showDestinations=true;
}
postDaemon(){

  this.post.postConfig(this.selectedDaemon);
}
postTask(){

  this.post.postTask(this.selectedTask);
}
postConfig(){

  this.post.postConfig(this.selectedConfig);
}
postSource(){

  this.post.postSource(this.selectedSource);
}
postDestination(){

  this.post.postDestination(this.selectedDestination);
}


daemonsNavigate()
{
  this.router.navigateByUrl('/adminDaemons');
}
configsNavigate()
{
  this.router.navigateByUrl('/admin');
}
changeStatus(daemons)
{
 this.close();
  this.onSelect(daemons);
}
close()
{ 
  this.showHide = !this.showHide;
}



}