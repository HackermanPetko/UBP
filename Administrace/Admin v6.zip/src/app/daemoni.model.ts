
export class Daemoni
{
    Id: number;
    IsNew: boolean;
    DaemonName: string;
    DaemonMAC: string;
    LastConnecteD: DateTimeFormat;
    Comment: string;
}
