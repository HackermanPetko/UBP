import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginFormComponent } from './login-form/login-form.component';
import { AdminComponent } from './admin/admin.component';
import { Admin2Component } from './admin2/admin2.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { DaemonslistComponent } from './daemonslist/daemonslist.component';
import { TaskslistComponent } from './taskslist/taskslist.component';
import { UserComponent } from './Users/user.component';


const routes: Routes = [
  {   path: '',
      component: LoginFormComponent,
  },
  {   path: 'admin',
      component: AdminComponent
  },
  {   path: 'adminDaemons',
  component: Admin2Component
  },
  {   path: 'Dashboard',
  component: DashboardComponent
  },
  {   path: 'daemons',
  component: DaemonslistComponent
  },
  {   path: 'tasks/:id',
  component: TaskslistComponent
  },
  {   path: 'users',
  component: UserComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

